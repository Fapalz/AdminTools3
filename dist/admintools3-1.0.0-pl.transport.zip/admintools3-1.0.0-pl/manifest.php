<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '# AdminTools3 1.0.0

Дополнительные инструменты для менеджера MODX Revolution 3. После установки обновите страницу менеджера. Плагин **AdminTools3** должен быть включён в категории «AdminTools3».

## Как пользоваться

- **Избранное.** Откройте вкладку «Элементы». Наведите курсор на шаблон, TV, чанк, сниппет или плагин и нажмите звезду справа от названия. Кнопка со звездой над разделом «Шаблоны» показывает только избранные элементы сразу во всех разделах; повторное нажатие возвращает полный список.
- **История изменений.** Кнопка с часами рядом с избранным открывает список недавно изменённых элементов. В окне можно искать и открывать элементы.
- **События плагинов.** Кнопка списка в строке «Плагины» открывает таблицу плагинов по событиям. Там доступны поиск, включение и отключение плагинов и управление их привязками.
- **Заметки.** Откройте меню профиля и выберите «Заметки» под пунктом «Сообщения». Можно создавать личные и общие заметки, искать их, а также импортировать и экспортировать JSON. Личные заметки видны только своему автору.
- **Связанные ресурсы.** В редакторе шаблона вкладка «Ресурсы» показывает использующие его ресурсы. В редакторе ресурса доступна вкладка альтернативных прав доступа, если эта функция включена в настройках.
- **Внешний вид.** В системных настройках выберите пространство имён `admintools3`. Параметр `admintools3_theme` переключает тему (`default`, `dark`, `purple`). Через `admintools3_custom_css` и `admintools3_custom_js` можно подключить свои файлы для менеджера; несколько URL разделяются запятыми.

Там же включаются или отключаются отдельные функции: избранное, история элементов, заметки, интерфейс событий плагинов, альтернативные права, выборочная очистка кеша, блокировка менеджера и вход по ссылке. Поиск в TV с множественным выбором поддерживает русские названия вариантов.

## Обновление и удаление

Если на сайте был установлен AdminTools, первая установка переносит его настройки, заметки, права и пользовательские предпочтения. Исходные данные остаются в старом пакете. Для старой формы входа замените вызов `[[!adminLogin]]` на `[[!adminLogin3]]` перед удалением AdminTools.

При деинсталляции вариант MODX «Сохранение» оставляет данные AdminTools3 для повторной установки. Вариант «Деинсталлировать» удаляет его заметки, альтернативные права, настройки и пользовательские предпочтения. Данные прежнего AdminTools не затрагиваются.

Исходный автор AdminTools: Sergey Shlokov (sergant210). Лицензия: GPL v2.
',
    'changelog' => 'AdminTools3 1.0.0-pl
====================
- First stable release for MODX Revolution 3.
- Add a package usage guide to the installer and display the package as AdminTools3
  after installation.
- Avoid a PHP warning when an anonymous visitor has no user profile.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '567fdc95b218c9450722541b77486351',
      'native_key' => 'admintools3',
      'filename' => 'MODX/Revolution/modNamespace/8846b6c22526c35a15c769898c734747.vehicle',
      'namespace' => 'admintools3',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e0a1ff6714768c42ea899fee085a98fb',
      'native_key' => 'admintools3_migration_version',
      'filename' => 'MODX/Revolution/modSystemSetting/467995c843042741b0a8cc92514c55f8.vehicle',
      'namespace' => 'admintools3',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '13b5f99a1830affd12a439b72a9b3a6e',
      'native_key' => 'admintools3_favorites_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/8d79a358643a4aca03a37b075fbf8d0d.vehicle',
      'namespace' => 'admintools3',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1bd9d89c1821055452f158b3e9541478',
      'native_key' => 'admintools3_check_elements_permissions',
      'filename' => 'MODX/Revolution/modSystemSetting/b8870bc330b9404def1946d7673ee955.vehicle',
      'namespace' => 'admintools3',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac42d5440b2ebe25afadad435ba54c88',
      'native_key' => 'admintools3_remember_system_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/9f35974e16da1b34bbfffd1d9a4b0018.vehicle',
      'namespace' => 'admintools3',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e38d655e4be24c176d94fa54371a7243',
      'native_key' => 'admintools3_enable_elements_log',
      'filename' => 'MODX/Revolution/modSystemSetting/44af75cb1daac7ad50291ac277ec520b.vehicle',
      'namespace' => 'admintools3',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b23024b89afdcd37df9bad8d8e67f8b3',
      'native_key' => 'admintools3_enable_favorite_elements',
      'filename' => 'MODX/Revolution/modSystemSetting/5afb5872bc284ce5683af9c35e9b9fa0.vehicle',
      'namespace' => 'admintools3',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a0fef72381c9c11dfcc0b37d895a8eb',
      'native_key' => 'admintools3_clear_only_resource_cache',
      'filename' => 'MODX/Revolution/modSystemSetting/a1fd35289f2ec7438ebf9fba249b78da.vehicle',
      'namespace' => 'admintools3',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ddd4450119fc6aafe7515facceba0e23',
      'native_key' => 'admintools3_hide_component_description',
      'filename' => 'MODX/Revolution/modSystemSetting/4534317fc6352018c0d2c270e4999e5e.vehicle',
      'namespace' => 'admintools3',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82141b8edea9bbac6a2c226ffeb763f4',
      'native_key' => 'admintools3_email_authorization',
      'filename' => 'MODX/Revolution/modSystemSetting/374737a67575cf462708c51d07d65852.vehicle',
      'namespace' => 'admintools3',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f38ae0a3afd43ab7fb9dffb3ff22cdec',
      'native_key' => 'admintools3_authorization_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/a0ce7cc043b26b1b1ad99df530ac8c0f.vehicle',
      'namespace' => 'admintools3',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa3cfc7367e81c183a8fecbf3935eb16',
      'native_key' => 'admintools3_loginform_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/698b8f86192320ff942369abc7a2bbde.vehicle',
      'namespace' => 'admintools3',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '277a40b76fea3842426ad55bb25ae199',
      'native_key' => 'admintools3_enable_notes',
      'filename' => 'MODX/Revolution/modSystemSetting/f5502c2c16983f5206075e819d609f4c.vehicle',
      'namespace' => 'admintools3',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'adf2fc99c22ab99c39c40819234319fb',
      'native_key' => 'admintools3_template_resource_relationship',
      'filename' => 'MODX/Revolution/modSystemSetting/21a4d15596007e61ca528e87e3be9af5.vehicle',
      'namespace' => 'admintools3',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be9280aa0ecc7d4147406bfe0c4fce42',
      'native_key' => 'admintools3_alternative_permissions',
      'filename' => 'MODX/Revolution/modSystemSetting/b906c197cf02508d4d1e5a8d48fed407.vehicle',
      'namespace' => 'admintools3',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0c4c2cd4431e785ff69168875c0094b1',
      'native_key' => 'admintools3_plugins_events',
      'filename' => 'MODX/Revolution/modSystemSetting/612927e3344946e74e83d25e332ee7f5.vehicle',
      'namespace' => 'admintools3',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9fa325baaae0221a3adc47caec9b27d9',
      'native_key' => 'admintools3_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/48d0599d3192c88b52d109cd74836b53.vehicle',
      'namespace' => 'admintools3',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e0535c98fe11ffd3a890779ba0585be',
      'native_key' => 'admintools3_modx_tree_position',
      'filename' => 'MODX/Revolution/modSystemSetting/02bc0b4ce652ed00a9459cce01c07b6b.vehicle',
      'namespace' => 'admintools3',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f905d7adf1acf5b4dfd7cc3db48e00be',
      'native_key' => 'admintools3_custom_css',
      'filename' => 'MODX/Revolution/modSystemSetting/7e6e4bbe142ef8b75562fe9d07db133a.vehicle',
      'namespace' => 'admintools3',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e7906f111b94c4ba830f4cafc4d91f3',
      'native_key' => 'admintools3_custom_js',
      'filename' => 'MODX/Revolution/modSystemSetting/c826a0fd6bb337ab55abfab747c88e8f.vehicle',
      'namespace' => 'admintools3',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '89a00dc44c2778a09f70a0e755ccc23a',
      'native_key' => 'admintools3_package_actions',
      'filename' => 'MODX/Revolution/modSystemSetting/bd7d0fae40ee647d1b4322396707a774.vehicle',
      'namespace' => 'admintools3',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62d886e2be60233c13766a98c97416ab',
      'native_key' => 'admintools3_only_current_context_user',
      'filename' => 'MODX/Revolution/modSystemSetting/f4373551e590c7966e5bd6464131b24c.vehicle',
      'namespace' => 'admintools3',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62078fd30b5f1280a8d248e7f2cbee8f',
      'native_key' => 'admintools3_show_lockmenu',
      'filename' => 'MODX/Revolution/modSystemSetting/230d9a849ebee47b30d50f995cccb5e9.vehicle',
      'namespace' => 'admintools3',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '887520be08db721d3462f9b0a8cf1188',
      'native_key' => 'admintools3_lock_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/d403108a85891a37f7c2dd4a12f8a6ec.vehicle',
      'namespace' => 'admintools3',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '866e01646702cd184c722811cf3d22eb',
      'native_key' => 'admintools3_unlock_code',
      'filename' => 'MODX/Revolution/modSystemSetting/9edccf0e5b018e3c0f273392c66ba258.vehicle',
      'namespace' => 'admintools3',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '6a0abeec50d60cfd255693ba2620b723',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/c4060e9c37226750d761b5b7af5aee41.vehicle',
      'namespace' => 'admintools3',
    ),
  ),
);